#!/usr/local/bin/php
<?php

// Make sure it has the credentials for our database.
require('config.inc.php');

// Create the DB object and statement to purge old tokens, then execute it
$db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);
$purgeStmt = $db->prepare("DELETE FROM passwordReset WHERE created < DATE_SUB(NOW(),INTERVAL 1 HOUR)");
$purgeStmt->execute();

// Kill the DB object
$db =null;
?>
