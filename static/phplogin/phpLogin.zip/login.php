<?php
// A whole whack of error and other variables to GET
$invalidCred = $_GET['invalidcreds'];
$passMismatch = $_GET['passMismatch'];
$nullPass = $_GET['nullPass'];
$usernameLength = $_GET['usernameLength'];
$userTaken = $_GET['userTaken'];
$emailTaken = $_GET['emailTaken'];
$email = $_GET['email'];
$username = $_GET['username'];
?>

<!DOCTYPE HTML>
<html>
  <head>
    <link href="style.css" media="screen" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="login-main">
      <div id="login">
        <form id="login_form" action="login_handler.php" method="POST">
          Login with an exisiting account:<br>
          <? // Insert an error messae into the form if needed
            if ($invalidCred == 1){
              echo "<p class='error-message'>The username or password entered was invalid</p>";
            }
          ?>
          <input type="text" name="username" placeholder=" Username"><br>
          <input type="password" name="password" placeholder=" Password"><br>
          <input type="submit" value="Login" class="form-submit">
        </form>
        <p>
        <a href="reset_form.php">Forgot Password?</a>
        </p>
      </div>
      <div id="registration">
        <form id="registration_form" action="registration_handler.php" method="POST">
          Dont have an account? Sign up:<br>
          <? // A whole lot more of the error message handling
            if ($emailTaken){
              echo "<p class='error-message'>The email entered is already in use, please use another one or log in with your existing account.</p>";
            }
          ?>
          <input type="email" name="email" placeholder=" yourEmail@example.com" VALUE="<?=$email?>"><br>
          <?
            if ($userTaken){
              echo "<p class='error-message'>The username selected is already in use, please pick another one.</p>";
            }
            if ($usernameLength){
              echo "<p class='error-message'>The username selected is excessively long, please pick one less than 30 characters.</p>";
            }
          ?>
          <input type="text" name="username" placeholder=" Preferred username" maxlength="32" VALUE="<?=$username?>"><br>
          <? 
            if ($passMismatch){
              echo "<p class='error-message'>The entered passwords did not match, please ensure they are entered correctly.</p>";
            }
            if ($nullPass){
              echo "<p class='error-message'>You must enter a password to register.</p>";
            }
          ?>
          <input type="password" name="password" placeholder=" Enter password"><br>
          <input type="password" name="pwordconfirm" placeholder=" Re-enter password"><br>
          <input type="submit" value="Register" class="form-submit">
        </form>
      </div>
    </div>
    <script src="Placeholders.min.js"></script>
    <script> Placeholders.init();</script>
  </body>
</html>
