<?php
// All of the error variables we need to GET
$userID = $_GET['userid'];
$userIDInt = (int)$userID;
$uuid_token = $_GET['UUID'];
$resetValidated = FALSE;
$targetURL = 'password_reset.php?userid=' . $userID . '&UUID=' . $uuid_token;
$passMismatch = $_GET['passMismatch'];
$nullPass = $_GET['nullPass'];

// Require the MySQL DB credentials.
require('config.inc.php');

// Make the DB object for our requests, and validate the reset token.
$db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);
$validateReset = $db->prepare("SELECT UUID FROM passwordReset WHERE userid = :userid");
$validateReset->bindParam(':userid', $userIDInt, PDO::PARAM_INT);
$validateReset->execute();
$result = $validateReset->fetch(PDO::FETCH_ASSOC);
$db =null; // We're done with the DB.
if (!$result) {
  echo "The URL entered is not valid for a password reset.";
  die();
}

$storedUUID = $result['UUID'];

// Check that the user id and uuid are valid before giving 
// the user access to change passwords
if($storedUUID != $uuid_token){
  echo "The URL entered is not valid for a password reset.";
  die();
}
?>

<!DOCTYPE HTML>
<html>
  <head>
    <link href="style.css" media="screen" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="change">
      <p>
        <form id="reset-form" action="<?=$targetURL?>" method="POST">
          Change Password: <br>
          <? // Error messages for the form
            if ($passMismatch){
              echo "<p class='error-message'>The new passwords did not match, please type them in carefully.</p>";
            }
            if ($nullPass){
              echo "<p class='error-message'>You cannot enter an empty password.</p>";
            }     
          ?>
          <input type="password" name="newpassword" placeholder=" New password"><br>
          <input type="password" name="passwordconf" placeholder=" Confirm password"><br>
          <input type="submit" value="Update" class="form-submit">
        </form>
      </p>
    </div>
    <script src="Placeholders.min.js"></script>
    <script> Placeholders.init();</script>
  </body>
</html>
