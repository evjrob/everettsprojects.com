<!DOCTYPE HTML>
<html>
  <head>
    <link href="style.css" media="screen" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="change">
      <p>
        Success, an email with instructions for reseting your password has been sent to the following email:
      </p>
      <p style="text-align:center;">
      <?php
        $email = $_GET["email"];
        echo $email;
      ?>
      </p>
    </div>
  </body>
</html>
