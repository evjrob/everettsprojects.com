<?php
// Functions for session management
function isLoggedIn(){
  if(isset($_SESSION['valid']) && $_SESSION['valid'])
    return true;
  return false;
}

function logout(){
  $_SESSION = array(); //destroy all of the session variables
  session_destroy();
}

session_start();
// If the user has not logged in, then kick them out!
if(!isLoggedIn()){
    header('Location: login.php');
    die();
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <link href="style.css" media="screen" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <div id="index-main">
            <p style="text-align:right;"><a href="logout.php">Logout</a> - <a href="change_form.php">Change password</a></p>
      <img src="2012-09-26 02.35.55.jpg" height="600">
      <p>Hmmm... There isn't really a point to this website other than the login script, so here's a picture of my dog.</p>
        </div>
    </body>
</html>
