<?php

// Fetch the variables included with GET
$userID = $_GET['userid'];
$userIDInt = (int)$userID;
$uuid_token = $_GET['UUID'];
$resetValidated = FALSE;

// Require the MySQL DB credentials.
require('config.inc.php');

// Make the DB object for our requests and check the reset is legit
$db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);
$validateReset = $db->prepare("SELECT UUID FROM passwordReset WHERE userid = :userid");
$validateReset->bindParam(':userid', $userIDInt, PDO::PARAM_INT);
$validateReset->execute();
$result = $validateReset->fetch(PDO::FETCH_ASSOC);
if (!$result) {
  echo "The URL entered is not valid for a password reset.";
  $db =null;
  die();
}
$storedUUID = $result['UUID'];

// Check that the user id and uuid are valid before giving 
// the user access to change passwords
if($storedUUID != $uuid_token){
  echo "The URL entered is not valid for a password reset.";
  $db =null;
  die();
}
// Do all the other stuff the page is meant to.
else{ 

  $newPassword = $_POST['newpassword'];
  $passwordConf = $_POST['passwordconf'];

  // Check that the user didn't mistype the new password
  if($newPassword != $passwordConf){
      $db =null;
      header("Location: reset_form2.php?passMismatch=1&userid=" . $userID . '&UUID=' . $uuid_token);
      die();
  }
  // No null passwords allowed either
  elseif(empty($newPassword)){
      header("Location: reset_form2.php?nullPass=1&userid=" . $userID . '&UUID=' . $uuid_token);
      die();
  }
  // Okay cool, go ahead with the password reset
  else{
      
    // Shamelessly copied from http://stackoverflow.com/questions/4356289/php-random-string-generator
    function generateRandomString($length = 22) {    
      return substr(str_shuffle("./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, $length);
    }

    $salt = generateRandomString(22);
    // "$2y$12$" indicates we're using blowfish with cost of 12
    // We're using blowfish because it seems to recommended. It's also convenient.
    $newHash = crypt($newPassword, "$2y$12$".$salt);
     
    $changePassStmt = $db->prepare("UPDATE users SET password_hash = :newHash WHERE id = :userid");
    $changePassStmt->bindParam(':userid', $userID, PDO::PARAM_INT);
    $changePassStmt->bindParam(':newHash', $newHash, PDO::PARAM_STR, 64);
    $changePassStmt->execute();
      
    // That reset code was successfully used, we want to remove it now.
    $removeUUID = $db->prepare("DELETE FROM passwordReset WHERE userid = :userid");
    $removeUUID->bindParam(':userid', $userIDInt, PDO::PARAM_INT);
    $removeUUID->execute();
      

    $db =null; // Kill the DB object.
     
    header('Location: index.php');
    die();
  }
}
?>
