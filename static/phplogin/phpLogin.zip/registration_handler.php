<?php

//Shamelessly copied from http://stackoverflow.com/questions/4356289/php-random-string-generator
function generateRandomString($length = 22) {    
    return substr(str_shuffle("./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, $length);
}

// From http://www.bin-co.com/php/scripts/misc/getlink/
/**
 * Create a link by joining the given URL and the parameters given as the second argument.
 * Arguments :  $url - The base url.
 *                $params - An array containing all the parameters and their values.
 *                $use_existing_arguments - Use the parameters that are present in the current page
 * Return : The new url.
 * Example : 
 *            getLink("http://www.google.com/search",array("q"=>"binny","hello"=>"world","results"=>10));
 *                    will return
 *            http://www.google.com/search?q=binny&amp;hello=world&amp;results=10
 */
function getLink($url,$params=array(),$use_existing_arguments=false) {
    if($use_existing_arguments) $params = $params + $_GET;
    if(!$params) return $url;
    $link = $url;
    if(strpos($link,'?') === false) $link .= '?'; //If there is no '?' add one at the end
    elseif(!preg_match('/(\?|\&(amp;)?)$/',$link)) $link .= '&'; //If there is no '&' at the END, add one.
    
    $params_arr = array();
    foreach($params as $key=>$value) {
        if(gettype($value) == 'array') { //Handle array data properly
            foreach($value as $val) {
                $params_arr[] = $key . '[]=' . urlencode($val);
            }
        } else {
            $params_arr[] = $key . '=' . urlencode($value);
        }
    }
    $link .= implode('&',$params_arr);
    
    return $link;
} 

$regOK = TRUE;
$errors=array();

$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$passwordConf = $_POST['pwordconfirm'];

// For preserving form data
$errors['username'] = $username;
$errors['email'] = $email;

// Require the MySQL DB credentials.
require('config.inc.php');

if($password != $passwordConf){
  $errors['passMismatch'] = TRUE;
  $regOK =FALSE;
  }
if(empty($password)){
  $errors['nullPass'] = TRUE;
  $regOK =FALSE;
  }
if(strlen("$username") > 30){
  $errors['usernameLength'] = TRUE;
  $regOK =FALSE;
  }

// Prepare an SQL statement to check of the username is taken.
$db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);
$checkUsername = $db->prepare("SELECT username FROM users WHERE username=:username LIMIT 1");
$checkUsername->bindParam(':username', $username, PDO::PARAM_STR, 32);
$checkUsername->execute();
$row = $checkUsername->fetch(PDO::FETCH_ASSOC);
if ($row) {
  $errors['userTaken'] = TRUE;
  $regOK =FALSE;
}
// Do the same to check of the email is taken.
$checkEmail = $db->prepare("SELECT email FROM users WHERE email=:email LIMIT 1");
$checkEmail->bindParam(':email', $email, PDO::PARAM_STR, 254);
$checkEmail->execute();
$row = $checkEmail->fetch(PDO::FETCH_ASSOC);
if ($row) {
  $errors['emailTaken'] = TRUE;
  $regOK =FALSE;
}
// Everything checks out, we can create the account now
if ($regOK){
    $salt = generateRandomString(22);
    // "$2y$12$" indicates we're using blowfish with cost of 12
    // We're using blowfish because it seems to recommended. It's also convenient.
    $hash = crypt($password, "$2y$12$".$salt);
    
    $stmt = $db->prepare("INSERT INTO users ( username, email, password_hash ) VALUES (:username,:email,:password_hash)");

    /*** execute the prepared statement ***/
    $stmt->execute(array(':username'=>$username,
                        ':email'=>$email,
                        ':password_hash'=>$hash));
    
    $db =null;

    header('Location: index.php');
}
else{
   $db =null;
   
   $targetUrl = getLink("login.php", $errors);
   header('Location: '.$targetUrl);
   
}

?>
