<!DOCTYPE HTML>
<html>
  <head>
    <link href="style.css" media="screen" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="change">
      <p>
        <form id="reset_form" action="request_reset.php" method="POST">
          <p>Password recovery: </p>
          Please enter the email you used when signing up for the account.<br>
          <?php
            //we want to display an error message if the user is redirected back to this page due to
            //a bad email.
            if ($_GET["invalidemail"]==1){
              echo "<p style=\"color: red;\">The email entered is not registered with any accounts.</p>";
            }
          ?>
          <input type="email" name="email" placeholder=" yourEmail@example.com" size="23"><br>
          <input type="submit" value="Submit" class="form-submit">
        </form>
      </p>
    </div>
  </body>
</html>