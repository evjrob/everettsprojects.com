<?php
// Various get parameters for error messages
$passMismatch = $_GET['passMismatch'];
$badPass = $_GET['badPass'];
$nullPass = $_GET['nullPass'];

// Check if viewer is logged in for session management purposes
function isLoggedIn(){
  if(isset($_SESSION['valid']) && $_SESSION['valid'])
    return true;
  return false;
}

// Start the session
session_start();
// If the user has not logged in, then kick them out!
if(!isLoggedIn()){
  header('Location: login.php');
  die();
}
?>

<!DOCTYPE HTML>
<html>
  <head>
    <link href="style.css" media="screen" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="change">
      <h3>Change Password:</h3>
      <form id="change-form" action="password_change.php" method="POST">
        <? // Insert the error messages into the form as appropriate
          if ($passMismatch){
            echo "<p class='error-message'>The new passwords did not match, please type them in carefully.</p>";
          }
          if ($badPass){
            echo "<p class='error-message'>The existing password you entered is not correct. Please enter it carefully.</p>";
          }
          if ($nullPass){
            echo "<p class='error-message'>You cannot enter an empty password.</p>";
          }
        ?> 
        <input type="password" name="oldpassword" placeholder=" Existing password"><br>
        <input type="password" name="newpassword" placeholder=" New password"><br>
        <input type="password" name="passwordconf" placeholder=" Confirm password"><br>
        <input type="submit" value="Update" class="form-submit">
      </form>
    </div>
    <script src="Placeholders.min.js"></script>
    <script> Placeholders.init();</script>
  </body>
</html>
