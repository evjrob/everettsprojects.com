<?php
// Just a simple Logout page that kills the session and send the user to
// the index page / login form.
session_start();

function logout(){
$_SESSION = array(); //destroy all of the session variables
  session_destroy();
}

logout();
header('Location: index.php');
die();
?>
