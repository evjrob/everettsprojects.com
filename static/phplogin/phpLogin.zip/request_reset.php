<?php 
////////////////////////////////////////////////////////////////////////
// You will want to update the all of the email related stuff below to 
// be suitable for your own web site. Don't forget to change this stuff.
////////////////////////////////////////////////////////////////////////

$email = $_POST['email'];

// Require the MySQL DB credentials.
require('config.inc.php');

// Check that the email entered is real before doing anything else
$db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);
$checkEmail = $db->prepare("SELECT id FROM users WHERE email=:email LIMIT 1");
$checkEmail->bindParam(':email', $email, PDO::PARAM_STR, 254);
$checkEmail->execute();
$row = $checkEmail->fetch(PDO::FETCH_ASSOC);
if (!$row) {
  header("Location: reset_form.php?invalidemail=1");
  die();
}

// Get the user ID number
$userID = $row['id'];
// Create a Reset Token and add it to the passwordReset DB
$uuid_token = md5(uniqid(rand(), true));
$addUUID = $db->prepare("INSERT INTO passwordReset (userid, UUID) VALUES (:userid,:UUID) ON DUPLICATE KEY UPDATE UUID=:UUID");
$addUUID->bindParam(':userid', $userID, PDO::PARAM_INT);
$addUUID->bindParam(':UUID', $uuid_token, PDO::PARAM_STR, 64);
$addUUID->execute();

// The stuff to send the email including a reset URL.
// DONT FORGET TO MAKE THESE VALUES SUIT YOUR OWN SITE:
$resetURL = >>>YOUR WEBSITE<<<."/reset_form2.php?userid=".$userID."&UUID=".$uuid_token;
$subject = 'Request to reset password at >>>YOUR WEBSITE<<<'; // UPDATE THIS LINE
$message = "
<html>
<head>
<title>Request to reset password at >>>YOUR WEBSITE<<<</title>
</head>
<body>
<p>
We have recieved a request to reset your password at >>>YOUR WEBSITE<<<. If this was not solicited by yourself, then you may ignore this email.
</p>
<p>To reset your email, please follow the following link:
<br><a href=\"".$resetURL."\">".$resetURL."</a></p>
<p>This link will expire between approximately 1 hour after creation. Please use it as soon as possible.</p></body></html>";
$headers = 'MIME-Version: 1.0' . "\r\n" .
  'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
  'From: >>>YOUR WEBSITE EMAIL<<<' . "\r\n" .
  'Reply-To: >>>YOUR WEBSITE EMAIL<<<' . "\r\n" .
  'X-Mailer: PHP/' . phpversion();
mail($email,$subject,$message,$headers);

$db =null; // Kill the DB object, we're done with it

header("Location: reset_conf.php?email=".$email);

?>
