<?php
//Session management
session_start();

function validateUser(){
    session_regenerate_id (); //this is a security measure
    $_SESSION['valid'] = 1;
    $_SESSION['username'] = $username;
}

$username = $_POST['username'];
$password = $_POST['password'];

require('config.inc.php');

$db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);
//By using PDO and prepare, everything is automagically escaped
$stmt = $db->prepare("SELECT password_hash FROM users WHERE username = :username");
$stmt->bindParam(':username', $username, PDO::PARAM_STR, 32);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$db =null;
    
$dbhash = $result['password_hash'];

if ($dbhash == crypt($password, $dbhash)){
   validateUser(); 
   header('Location: index.php');
}
else{ //Send the user back to this page with meaningful error message.
    header('Location: login.php?invalidcreds=1');
    die();
}

?>
