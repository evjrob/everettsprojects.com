<?php

//Double check that people accessing this are logged in, and belong here
function isLoggedIn(){
  if(isset($_SESSION['valid']) && $_SESSION['valid'])
    return true;
  return false;
}
session_start();

// If the user has not logged in, then kick them out!
if(!isLoggedIn()){
  header('Location: login.php');
  die();
}
// Do all the other things the page is supposed to do
else{
  // Get the variables passed from change_form.php
  $oldPassword = $_POST['oldpassword'];
  $newPassword = $_POST['newpassword'];
  $passwordConf = $_POST['passwordconf'];
  $username = $_SESSION['username'];

  // Check that the user didn't mistype the new password
  if($newPassword != $passwordConf){
    header("Location: change_form.php?passMismatch=1");
    die();
  }
  // No null passwords either
  elseif(empty($newPassword)){
    header("Location: change_form.php?nullPass=1");
    die();
  }

  //require the MySQL DB credentials.
  require('config.inc.php');

  // Make the DB object for our requests
  $db = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);

  // Check that the user entered correct old password.
  $getPassStmt = $db->prepare("SELECT password_hash FROM users WHERE username = :username");
  $getPassStmt->bindParam(':username', $username, PDO::PARAM_STR, 32);
  $getPassStmt->execute();
  $result = $getPassStmt->fetch(PDO::FETCH_ASSOC);
  $dbhash = $result['password_hash'];

  if ($dbhash == crypt($oldPassword, $dbhash)){
    
    // Shamelessly copied from http://stackoverflow.com/questions/4356289/php-random-string-generator
    function generateRandomString($length = 22) {    
      return substr(str_shuffle("./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, $length);
    }
     
    // Okay the pass word was good, set up to replace it with the new one.
    $salt = generateRandomString(22);
    // "$2y$12$" indicates we're using blowfish with cost of 12
    // We're using blowfish because it seems to recommended. It's also convenient.
    $newHash = crypt($newPassword, "$2y$12$".$salt);
     
    $changePassStmt = $db->prepare("UPDATE users SET password_hash = :newHash WHERE username = :username");
    $changePassStmt->bindParam(':username', $username, PDO::PARAM_STR, 32);
    $changePassStmt->bindParam(':newHash', $newHash, PDO::PARAM_STR, 64);
    $changePassStmt->execute();

    $db =null; // Kill the DB object.
     
    header('Location: index.php');
    die();
  }
  else{ // Send the user back to this page with meaningful error message.
    $db =null;
    header('Location: change_form.php?badPass=1');
    die();
  }
}
?>
